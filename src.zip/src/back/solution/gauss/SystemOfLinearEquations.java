package back.solution.gauss;

import java.util.ArrayList;
import java.util.List;

public class SystemOfLinearEquations<N extends Number, T extends Gauss<N, T>> {
    private List<T> list = new ArrayList<>();

    public T get(int index){
        return list.get(index);
    }

    public void push(T elem){
        list.add(elem);
    }

    public int size(){
        return list.size();
    }

    public N itemAt(int i, int j){
        return list.get(i).at(j);
    }
}