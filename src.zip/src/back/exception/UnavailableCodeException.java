package back.exception;

public class UnavailableCodeException extends Exception {
    public UnavailableCodeException() {
        super("Unavailable code!!!");
    }
}
